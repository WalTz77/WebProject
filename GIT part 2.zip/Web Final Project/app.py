from flask import Flask, abort, jsonify, redirect, render_template, request, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from models import db, User
from flask_login import login_user, logout_user, login_required, current_user
from flask_wtf.csrf import CSRFProtect





app = Flask(__name__)
app.config['SECRET_KEY'] = 'secrete_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Jado676869@localhost/users'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

csrf = CSRFProtect(app)
app.config.update(
    SESSION_COOKIE_SECURE=True,
    REMEMBER_COOKIE_SECURE=True
)

db.init_app(app)


login_manager = LoginManager(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


@app.route("/")
def index():
    return render_template("index.html")

@app.route("/create-account")
def create_account():
    return render_template("create-account.html")

@app.route("/event")
def event():
    return render_template("event.html")

@app.route("/forum")
def forum():
    return render_template("forum.html")

@app.route("/partner")
def partner():
    return render_template("partner.html")

@app.route("/tournaments")
def tournaments():
    return render_template("tournaments.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route('/admin')
@login_required
def admin():
    if current_user.role != 'admin':
        abort(403)
    return render_template('admin.html')

@app.route('/api/login', methods=['POST'])
def handle_login():
    data = request.get_json()
    user = User.query.filter_by(username=data['username']).first()
    
    if user and user.check_password(data['password']):
        login_user(user)
        return jsonify({'success': True, 'message': 'Logged in successfully'})
    return jsonify({'success': False, 'message': 'Invalid credentials'}), 401

@app.route('/api/logout')
@login_required
def handle_logout():
    logout_user()
    return jsonify({'success': True, 'message': 'Logged out successfully'})

@app.route('/api/register', methods=['POST'])
def handle_register():
    data = request.get_json()
    
    try:
        # Check if user exists
        if User.query.filter_by(username=data['username']).first():
            return jsonify({'error': 'Username exists'}), 400

        # Create user
        new_user = User(
            username=data['username'],
            email=data['email'],
            role='user'
        )
        new_user.set_password(data['password'])  # Hashes password
        
        # Save to database
        db.session.add(new_user)
        db.session.commit()
        
        # Log user in
        login_user(new_user)
        
        return jsonify({
            'success': True,
            'redirect': url_for('index')  # Dynamic URL generation
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500
    

    
    login_user(new_user)
    return jsonify({'success': True, 'message': 'Account created successfully'})


if __name__ == "__main__":
    app.run(debug=True)