// DOM Elements
const loginBtn = document.getElementById("loginBtn");
const logoutBtn = document.getElementById("logoutBtn");
const loginModal = document.getElementById("loginModal");
const closeModal = document.getElementById("closeModal");
const loginForm = document.getElementById("loginForm");
const hamburger = document.querySelector('.hamburger');

// Modal Handling (your existing code)
loginBtn?.addEventListener('click', () => loginModal.classList.remove("hidden"));
closeModal?.addEventListener('click', () => loginModal.classList.add("hidden"));
window.addEventListener('click', e => {
  if (e.target === loginModal) loginModal.classList.add("hidden");
});

// Hamburger menu (your existing code)
hamburger?.addEventListener('click', toggleMenu);

function toggleMenu() {
  const navbar = document.querySelector('.navbar');
  navbar.classList.toggle('open');
}

// New Authentication Functions
async function handleLogin(event) {
  event.preventDefault();
  
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  try {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password })
    });

    const result = await response.json();
    
    if (result.success) {
      // Close modal and refresh page
      loginModal.classList.add("hidden");
      window.location.reload();
    } else {
      alert(result.message || "Login failed");
    }
  } catch (error) {
    console.error('Login error:', error);
    alert("An error occurred during login");
  }
}

async function handleLogout() {
  try {
    const response = await fetch('/api/logout');
    const result = await response.json();
    
    if (result.success) {
      window.location.reload();
    }
  } catch (error) {
    console.error('Logout error:', error);
  }
}

// Event Listeners
if (loginForm) {
  loginForm.addEventListener('submit', handleLogin);
}

if (logoutBtn) {
  logoutBtn.addEventListener('click', handleLogout);
}

// Update UI based on auth state (if needed)
function updateAuthUI() {
  // You can add logic here to modify UI based on login state
  // For example: show/hide elements, change text, etc.
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  updateAuthUI();
});