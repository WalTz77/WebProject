document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const response = await fetch('/api/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            username: document.getElementById('reg-username').value,
            email: document.getElementById('reg-email').value,
            password: document.getElementById('reg-password').value
        })
    });
    
    const result = await response.json();
    if (result.success) {
        window.location.href = result.redirect;  // Flask-provided URL
    } else {
        alert(result.error || "Registration failed");
    }
});